package com.example.mychatapplication.utils;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class FirebaseUtils {
    public static String currentUserID(){

        return FirebaseAuth.getInstance().getUid();
    }

    public static DocumentReference currentUserDetails(){
        return FirebaseFirestore.getInstance().collection("Users").document(currentUserID());
    }

    public static CollectionReference allUserCollectionReference(){
        return FirebaseFirestore.getInstance().collection("Users");
    }

    public static DocumentReference getChatroomReference(String chatroomID){
        return FirebaseFirestore.getInstance().collection("Chatrooms").document(chatroomID);

    }

    public static String getChatroomID(String userID1, String userID2){
        if(userID1.hashCode()<userID2.hashCode()){
            return userID1+"_"+userID2;
        }else{
            return userID2+"_"+userID1;
        }
    }
}
