package com.example.mychatapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.mychatapplication.model.ChatroomModel;
import com.example.mychatapplication.model.UserModel;
import com.example.mychatapplication.utils.AndroidUtil;
import com.example.mychatapplication.utils.FirebaseUtils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;

import java.util.Arrays;

public class ChatActivity extends AppCompatActivity {

    UserModel otherUser;
    EditText messageInput;
    String chatroomID;
    ChatroomModel chatroomModel;
    ImageButton sendMessageBtn;

    TextView otherUsername;
    RecyclerView recyclerView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        otherUser = AndroidUtil.getUserModelFromIntent(getIntent());
        chatroomID = FirebaseUtils.getChatroomID(FirebaseUtils.currentUserID(),otherUser.getUserID());

        messageInput = findViewById(R.id.chat_message_input);
        sendMessageBtn = findViewById(R.id.message_send_btn);
        otherUsername = findViewById(R.id.other_username);
        recyclerView . findViewById(R.id.chat_recycler_view);

        otherUsername.setText(otherUser.getUsername());

        getOrCreateChatroomModel();

    }



    void getOrCreateChatroomModel() {
        FirebaseUtils.getChatroomReference(chatroomID).get().addOnCompleteListener(task -> {
            if(task.isSuccessful()){
                chatroomModel = task.getResult().toObject(ChatroomModel.class);
                if(chatroomModel==null){
                    chatroomModel = new ChatroomModel(
                            chatroomID,
                            Arrays.asList(FirebaseUtils.currentUserID(),otherUser.getUserID()),
                            Timestamp.now(),
                            ""
                    );
                    FirebaseUtils.getChatroomReference(chatroomID).set(chatroomModel);
                }
            }
        });
    }
}